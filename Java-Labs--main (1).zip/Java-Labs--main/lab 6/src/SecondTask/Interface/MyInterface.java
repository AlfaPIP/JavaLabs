package SecondTask.Interface;

public interface MyInterface {
    int count(int number);
}
