package TaskOne;

public class ClassOne {

    public ClassOne() {
        System.out.println("Object with type ClassOne was created!");
    }

    public int Sum(int a , int b) {
        return a + b;
    }

    public int Mul(int a, int b) {
        return a * b;
    }

    public int Min(int a, int b) {
        return  a - b;
    }

    public int Div(int a, int b) {
        return a / b;
    }
}
