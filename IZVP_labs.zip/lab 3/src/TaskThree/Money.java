package TaskThree;

public class Money extends Fractions {

    public Money(int decimal , int fractional) {
        super(decimal, fractional);
    }

}
