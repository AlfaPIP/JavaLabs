public class Main {
    public static void main(String[] args) {
        int[] testArray= {5,1,2,4}; //Array for testing arrayHalfChecker method
        boolean flag;
        flag = ZadOne.arrayHalfChecker(testArray);
        System.out.println(flag);
        /* int[] anotherTestArray = {1,2,5,3}; //Array for testing arrayChecker method
        flag = ZadOne.arrayChecker(anotherTestArray);
        System.out.println(flag);
        ZadOne.fizzBuzzPrinter();*/
    }
}

